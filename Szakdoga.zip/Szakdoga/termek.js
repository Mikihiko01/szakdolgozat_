class Termek{
    constructor(node, adat){
        this.node = node;
        this.adat = adat;
        this.termekNev = this.node.children(".termeknev");
        this.termekLeiras = this.node.children(".leiras");
        this.termekAr = this.node.children(".price");


    }
    setAdat(adat){
        this.adat = adat;
        this.termekNev.text(adat.nev);
        this.termekLeiras.text(adat.leiras);
        this.termekAr.text(adat.price + " Ft");
        this.termekKep.attr("src", adat.kep);
    }
    
}